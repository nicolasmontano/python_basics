def function_a():
    return "Function A"
