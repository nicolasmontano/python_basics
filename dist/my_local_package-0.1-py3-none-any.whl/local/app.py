from local.risk_1.module_b import function_b
from my_project.local.risk_1.module_a import function_a

if __name__ == '__main__':
    function_a()
    x=function_b()
    y=function_b()

