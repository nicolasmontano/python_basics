from .module_a import function_a


def function_b():
    return function_a() + " called from Function B"

