
from dataclasses import  dataclass


clas